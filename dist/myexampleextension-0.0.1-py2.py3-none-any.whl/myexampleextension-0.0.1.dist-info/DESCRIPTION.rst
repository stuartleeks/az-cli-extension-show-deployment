An example Azure CLI Extension.


